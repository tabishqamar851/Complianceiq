"""
ComplianceIQ - Main Application
India's Compliance Platform for RBI-regulated entities and CA firms
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
import time

from app.core.config import settings
from app.db.database import create_tables
from app.api.v1.endpoints import auth, users, billing


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    if settings.APP_ENV == "development":
        await create_tables()
        print("\n✅ ComplianceIQ API started in DEVELOPMENT mode")
        print("📚 Docs: http://localhost:8000/docs\n")
    yield
    # Shutdown (cleanup if needed)


app = FastAPI(
    title="ComplianceIQ API",
    description="""
## ComplianceIQ — India's Compliance Platform

Built for RBI-regulated entities, Forex dealers, and CA firms.

### Features
- 🔐 Multi-tenant authentication with 2FA
- 📋 FEMA / RBI / GST / AML compliance modules
- 💳 Razorpay subscription billing
- 📄 Automated compliance document generation
- 🔔 Deadline alerts & regulatory updates
- 📊 Audit trail (every action logged)

### Important Notice
> This platform assists compliance workflows. All outputs must be reviewed
> by a qualified CA or compliance officer before acting on them.
> ComplianceIQ is not liable for decisions made based on platform outputs.
    """,
    version="1.0.0",
    docs_url="/docs" if settings.APP_ENV != "production" else None,
    redoc_url="/redoc" if settings.APP_ENV != "production" else None,
    lifespan=lifespan,
)

# ─────────────────────────────────────────
# MIDDLEWARE
# ─────────────────────────────────────────

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.FRONTEND_URL, "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request timing middleware
@app.middleware("http")
async def add_process_time(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    response.headers["X-Process-Time"] = f"{(time.time() - start)*1000:.2f}ms"
    return response

# Security headers
@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    if settings.APP_ENV == "development":
        raise exc
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "An internal error occurred. Please contact support."},
    )

# ─────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────

app.include_router(auth.router, prefix="/api/v1")
app.include_router(users.router, prefix="/api/v1")
app.include_router(billing.router, prefix="/api/v1")


@app.get("/", tags=["Health"])
async def root():
    return {
        "service": "ComplianceIQ API",
        "version": "1.0.0",
        "status": "operational",
        "environment": settings.APP_ENV,
    }


@app.get("/health", tags=["Health"])
async def health():
    return {"status": "healthy"}
