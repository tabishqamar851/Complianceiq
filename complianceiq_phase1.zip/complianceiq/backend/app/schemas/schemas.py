from pydantic import BaseModel, EmailStr, Field, field_validator
from typing import Optional
from uuid import UUID
from datetime import datetime
from app.models.models import UserRole, TenantType, SubscriptionPlan, SubscriptionStatus


# ─────────── TENANT ───────────

class TenantCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=255)
    tenant_type: TenantType
    email: EmailStr
    phone: Optional[str] = None
    gstin: Optional[str] = None
    pan: Optional[str] = None
    rbi_license_no: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None

    @field_validator("gstin")
    @classmethod
    def validate_gstin(cls, v):
        if v and len(v) != 15:
            raise ValueError("GSTIN must be 15 characters")
        return v.upper() if v else v

    @field_validator("pan")
    @classmethod
    def validate_pan(cls, v):
        if v and len(v) != 10:
            raise ValueError("PAN must be 10 characters")
        return v.upper() if v else v


class TenantResponse(BaseModel):
    id: UUID
    name: str
    slug: str
    tenant_type: TenantType
    email: str
    is_active: bool
    is_verified: bool
    created_at: datetime

    model_config = {"from_attributes": True}


# ─────────── USER ───────────

class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=10)
    full_name: str = Field(..., min_length=2, max_length=255)
    phone: Optional[str] = None
    role: UserRole = UserRole.STAFF
    membership_no: Optional[str] = None  # ICAI for CAs


class UserResponse(BaseModel):
    id: UUID
    tenant_id: UUID
    email: str
    full_name: str
    role: UserRole
    is_active: bool
    is_email_verified: bool
    two_fa_enabled: bool
    last_login_at: Optional[datetime]
    created_at: datetime

    model_config = {"from_attributes": True}


# ─────────── AUTH ───────────

class RegisterRequest(BaseModel):
    """Register a new tenant + admin user"""
    tenant: TenantCreate
    user: UserCreate


class LoginRequest(BaseModel):
    email: EmailStr
    password: str
    totp_code: Optional[str] = None     # If 2FA enabled


class OTPVerifyRequest(BaseModel):
    email: EmailStr
    otp: str = Field(..., min_length=6, max_length=6)
    purpose: str


class RefreshTokenRequest(BaseModel):
    refresh_token: str


class PasswordResetRequest(BaseModel):
    email: EmailStr


class PasswordResetConfirm(BaseModel):
    email: EmailStr
    otp: str
    new_password: str = Field(..., min_length=10)


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str = Field(..., min_length=10)


class Setup2FAResponse(BaseModel):
    secret: str
    qr_uri: str


class Verify2FARequest(BaseModel):
    totp_code: str


# ─────────── TOKENS ───────────

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # seconds
    user: UserResponse
    tenant: TenantResponse


# ─────────── SUBSCRIPTION ───────────

class SubscriptionResponse(BaseModel):
    id: UUID
    plan: SubscriptionPlan
    status: SubscriptionStatus
    trial_ends_at: Optional[datetime]
    current_period_end: Optional[datetime]
    max_users: int
    max_entities: int
    task_credits: int

    model_config = {"from_attributes": True}


class CreateOrderRequest(BaseModel):
    plan: SubscriptionPlan


class CreateOrderResponse(BaseModel):
    order_id: str
    amount: int          # paise
    currency: str
    razorpay_key: str
    plan: str


# ─────────── MANAGED ENTITY ───────────

class EntityCreate(BaseModel):
    name: str = Field(..., min_length=2)
    entity_type: Optional[str] = None
    gstin: Optional[str] = None
    pan: Optional[str] = None
    cin: Optional[str] = None
    rbi_license_no: Optional[str] = None
    fema_ad_code: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    is_fema_applicable: bool = False
    is_rbi_regulated: bool = False
    fx_dealer_category: Optional[str] = None


class EntityResponse(BaseModel):
    id: UUID
    name: str
    entity_type: Optional[str]
    gstin: Optional[str]
    pan: Optional[str]
    is_fema_applicable: bool
    is_rbi_regulated: bool
    is_active: bool
    created_at: datetime

    model_config = {"from_attributes": True}
