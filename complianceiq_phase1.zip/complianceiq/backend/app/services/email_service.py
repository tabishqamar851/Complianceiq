"""Email service using Resend API"""
import httpx
from app.core.config import settings


OTP_TEMPLATES = {
    "email_verification": {
        "subject": "Verify your ComplianceIQ account",
        "action": "verify your email address",
    },
    "password_reset": {
        "subject": "Reset your ComplianceIQ password",
        "action": "reset your password",
    },
    "login": {
        "subject": "Your ComplianceIQ login OTP",
        "action": "log in to your account",
    },
}


async def send_otp_email(email: str, name: str, otp: str, purpose: str):
    template = OTP_TEMPLATES.get(purpose, OTP_TEMPLATES["login"])

    html = f"""
    <!DOCTYPE html>
    <html>
    <head><meta charset="utf-8"></head>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: #0f172a; padding: 30px; border-radius: 8px; text-align: center;">
            <h1 style="color: #22c55e; margin: 0; font-size: 24px;">ComplianceIQ</h1>
            <p style="color: #94a3b8; margin: 5px 0 0;">India's Compliance Platform</p>
        </div>
        <div style="padding: 30px 0;">
            <p style="color: #1e293b; font-size: 16px;">Hello {name},</p>
            <p style="color: #475569;">Use the following OTP to {template['action']}:</p>
            <div style="background: #f1f5f9; border-radius: 8px; padding: 20px; text-align: center; margin: 20px 0;">
                <span style="font-size: 36px; font-weight: bold; letter-spacing: 8px; color: #0f172a;">{otp}</span>
            </div>
            <p style="color: #64748b; font-size: 14px;">This OTP expires in {settings.OTP_EXPIRY_MINUTES} minutes.</p>
            <p style="color: #64748b; font-size: 14px;">If you did not request this, please ignore this email and contact support immediately.</p>
        </div>
        <div style="border-top: 1px solid #e2e8f0; padding-top: 20px;">
            <p style="color: #94a3b8; font-size: 12px; text-align: center;">
                ComplianceIQ — Trusted by RBI-regulated entities<br>
                Do not share this OTP with anyone, including ComplianceIQ staff.
            </p>
        </div>
    </body>
    </html>
    """

    if not settings.RESEND_API_KEY:
        # Development mode: print OTP
        print(f"\n{'='*50}\n📧 EMAIL TO: {email}\nOTP: {otp}\nPurpose: {purpose}\n{'='*50}\n")
        return

    async with httpx.AsyncClient() as client:
        try:
            await client.post(
                "https://api.resend.com/emails",
                headers={"Authorization": f"Bearer {settings.RESEND_API_KEY}"},
                json={
                    "from": f"{settings.FROM_NAME} <{settings.FROM_EMAIL}>",
                    "to": [email],
                    "subject": template["subject"],
                    "html": html,
                },
                timeout=10,
            )
        except Exception as e:
            print(f"Email send failed: {e}")  # Log but don't crash


async def send_welcome_email(email: str, name: str, tenant_name: str):
    if not settings.RESEND_API_KEY:
        print(f"\n📧 WELCOME EMAIL TO: {email} ({tenant_name})\n")
        return
    # Implementation similar to above
    pass
