"""
Auth Service - ComplianceIQ
Handles: Registration, Login, OTP, 2FA, Token refresh, Password reset
"""
import re
from datetime import datetime, timedelta, timezone
from typing import Optional
from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import (
    hash_password, verify_password, validate_password_strength,
    create_access_token, create_refresh_token, hash_token, decode_access_token,
    generate_otp, hash_otp, verify_otp_hash,
    generate_totp_secret, get_totp_uri, verify_totp
)
from app.models.models import (
    Tenant, User, RefreshToken, OTPCode, Subscription, AuditLog,
    TenantType, UserRole, SubscriptionPlan, SubscriptionStatus,
    OTPPurpose, AuditAction
)
from app.schemas.schemas import RegisterRequest, LoginRequest
from app.services.email_service import send_otp_email


def _generate_slug(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug[:50]


async def _ensure_unique_slug(db: AsyncSession, base_slug: str) -> str:
    slug = base_slug
    counter = 1
    while True:
        result = await db.execute(select(Tenant).where(Tenant.slug == slug))
        if not result.scalar_one_or_none():
            return slug
        slug = f"{base_slug}-{counter}"
        counter += 1


class AuthService:

    # ─────────────────────────────────────────
    # REGISTRATION
    # ─────────────────────────────────────────

    async def register(self, db: AsyncSession, data: RegisterRequest) -> dict:
        # 1. Check email not already registered
        existing = await db.execute(select(User).where(User.email == data.user.email))
        if existing.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Email already registered"
            )

        # 2. Validate password
        valid, msg = validate_password_strength(data.user.password)
        if not valid:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=msg)

        # 3. Create Tenant
        slug = await _ensure_unique_slug(db, _generate_slug(data.tenant.name))
        tenant = Tenant(
            name=data.tenant.name,
            slug=slug,
            tenant_type=data.tenant.tenant_type,
            email=data.tenant.email,
            phone=data.tenant.phone,
            gstin=data.tenant.gstin,
            pan=data.tenant.pan,
            rbi_license_no=data.tenant.rbi_license_no,
            city=data.tenant.city,
            state=data.tenant.state,
        )
        db.add(tenant)
        await db.flush()  # Get tenant ID

        # 4. Create Admin User
        user = User(
            tenant_id=tenant.id,
            email=data.user.email,
            full_name=data.user.full_name,
            phone=data.user.phone,
            hashed_password=hash_password(data.user.password),
            role=UserRole.TENANT_ADMIN,
            membership_no=data.user.membership_no,
        )
        db.add(user)
        await db.flush()

        # 5. Create default Subscription (14-day trial)
        sub = Subscription(
            tenant_id=tenant.id,
            plan=SubscriptionPlan.FREE,
            status=SubscriptionStatus.TRIAL,
            trial_ends_at=datetime.now(timezone.utc) + timedelta(days=14),
            max_users=3,
            max_entities=5,
            max_tasks_per_month=50,
        )
        db.add(sub)

        # 6. Send email verification OTP
        otp = generate_otp()
        otp_record = OTPCode(
            user_id=user.id,
            code_hash=hash_otp(otp),
            purpose=OTPPurpose.EMAIL_VERIFY,
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=settings.OTP_EXPIRY_MINUTES),
        )
        db.add(otp_record)

        # 7. Audit log
        audit = AuditLog(
            tenant_id=tenant.id,
            user_id=user.id,
            action=AuditAction.CREATE,
            resource_type="tenant",
            resource_id=str(tenant.id),
            description=f"New tenant registered: {tenant.name}",
        )
        db.add(audit)

        await db.commit()

        # 8. Send OTP email (non-blocking)
        await send_otp_email(user.email, user.full_name, otp, "email_verification")

        return {
            "message": "Registration successful. Please verify your email.",
            "email": user.email,
            "tenant_id": str(tenant.id),
        }

    # ─────────────────────────────────────────
    # EMAIL VERIFICATION
    # ─────────────────────────────────────────

    async def verify_email(self, db: AsyncSession, email: str, otp: str) -> dict:
        user = await self._get_user_by_email(db, email)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        otp_record = await self._get_valid_otp(db, user.id, OTPPurpose.EMAIL_VERIFY)
        if not otp_record or not verify_otp_hash(otp, otp_record.code_hash):
            await self._increment_otp_attempts(db, otp_record)
            raise HTTPException(status_code=400, detail="Invalid or expired OTP")

        user.is_email_verified = True
        otp_record.used = True
        await db.commit()

        return {"message": "Email verified successfully"}

    # ─────────────────────────────────────────
    # LOGIN
    # ─────────────────────────────────────────

    async def login(self, db: AsyncSession, data: LoginRequest, ip: str, user_agent: str) -> dict:
        user = await self._get_user_by_email(db, data.email)

        # Account lockout check
        if user and user.locked_until and user.locked_until > datetime.now(timezone.utc):
            raise HTTPException(
                status_code=status.HTTP_423_LOCKED,
                detail="Account temporarily locked due to too many failed attempts"
            )

        # Verify credentials
        if not user or not verify_password(data.password, user.hashed_password):
            if user:
                await self._handle_failed_login(db, user)
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password"
            )

        if not user.is_active:
            raise HTTPException(status_code=403, detail="Account deactivated")

        if not user.is_email_verified:
            raise HTTPException(status_code=403, detail="Please verify your email first")

        # 2FA check
        if user.two_fa_enabled:
            if not data.totp_code:
                raise HTTPException(
                    status_code=status.HTTP_202_ACCEPTED,
                    detail="2FA code required"
                )
            if not verify_totp(user.two_fa_secret, data.totp_code):
                raise HTTPException(status_code=401, detail="Invalid 2FA code")

        # Fetch tenant
        tenant = await db.get(Tenant, user.tenant_id)

        # Create tokens
        access_token = create_access_token(
            user_id=user.id,
            tenant_id=user.tenant_id,
            role=user.role.value,
            tenant_type=tenant.tenant_type.value,
        )
        refresh_token = create_refresh_token()
        token_hash = hash_token(refresh_token)

        # Store refresh token
        rt = RefreshToken(
            user_id=user.id,
            token_hash=token_hash,
            expires_at=datetime.now(timezone.utc) + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
            ip_address=ip,
            device_info=user_agent[:500] if user_agent else None,
        )
        db.add(rt)

        # Update login tracking
        user.last_login_at = datetime.now(timezone.utc)
        user.last_login_ip = ip
        user.failed_login_attempts = 0
        user.locked_until = None

        # Audit
        db.add(AuditLog(
            tenant_id=user.tenant_id,
            user_id=user.id,
            action=AuditAction.LOGIN,
            resource_type="user",
            resource_id=str(user.id),
            description="User logged in",
            ip_address=ip,
            user_agent=user_agent,
        ))

        await db.commit()

        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer",
            "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            "user": user,
            "tenant": tenant,
        }

    # ─────────────────────────────────────────
    # TOKEN REFRESH
    # ─────────────────────────────────────────

    async def refresh_tokens(self, db: AsyncSession, refresh_token: str) -> dict:
        token_hash = hash_token(refresh_token)
        result = await db.execute(
            select(RefreshToken).where(
                and_(
                    RefreshToken.token_hash == token_hash,
                    RefreshToken.revoked == False,
                    RefreshToken.expires_at > datetime.now(timezone.utc),
                )
            )
        )
        rt = result.scalar_one_or_none()
        if not rt:
            raise HTTPException(status_code=401, detail="Invalid or expired refresh token")

        user = await db.get(User, rt.user_id)
        tenant = await db.get(Tenant, user.tenant_id)

        # Rotate refresh token
        rt.revoked = True
        new_refresh = create_refresh_token()
        new_rt = RefreshToken(
            user_id=user.id,
            token_hash=hash_token(new_refresh),
            expires_at=datetime.now(timezone.utc) + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
        )
        db.add(new_rt)

        new_access = create_access_token(
            user_id=user.id,
            tenant_id=user.tenant_id,
            role=user.role.value,
            tenant_type=tenant.tenant_type.value,
        )

        await db.commit()
        return {
            "access_token": new_access,
            "refresh_token": new_refresh,
            "token_type": "bearer",
            "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        }

    # ─────────────────────────────────────────
    # PASSWORD RESET
    # ─────────────────────────────────────────

    async def request_password_reset(self, db: AsyncSession, email: str):
        user = await self._get_user_by_email(db, email)
        if not user:
            # Don't reveal if email exists
            return {"message": "If this email exists, you will receive an OTP"}

        otp = generate_otp()
        otp_record = OTPCode(
            user_id=user.id,
            code_hash=hash_otp(otp),
            purpose=OTPPurpose.PASSWORD_RESET,
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=settings.OTP_EXPIRY_MINUTES),
        )
        db.add(otp_record)
        await db.commit()
        await send_otp_email(user.email, user.full_name, otp, "password_reset")
        return {"message": "If this email exists, you will receive an OTP"}

    async def confirm_password_reset(self, db: AsyncSession, email: str, otp: str, new_password: str):
        valid, msg = validate_password_strength(new_password)
        if not valid:
            raise HTTPException(status_code=422, detail=msg)

        user = await self._get_user_by_email(db, email)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        otp_record = await self._get_valid_otp(db, user.id, OTPPurpose.PASSWORD_RESET)
        if not otp_record or not verify_otp_hash(otp, otp_record.code_hash):
            raise HTTPException(status_code=400, detail="Invalid or expired OTP")

        user.hashed_password = hash_password(new_password)
        user.failed_login_attempts = 0
        user.locked_until = None
        otp_record.used = True

        # Revoke all refresh tokens
        tokens = await db.execute(select(RefreshToken).where(RefreshToken.user_id == user.id))
        for t in tokens.scalars():
            t.revoked = True

        await db.commit()
        return {"message": "Password reset successful"}

    # ─────────────────────────────────────────
    # 2FA SETUP
    # ─────────────────────────────────────────

    async def setup_2fa(self, db: AsyncSession, user_id: UUID) -> dict:
        user = await db.get(User, user_id)
        secret = generate_totp_secret()
        user.two_fa_secret = secret  # In production: encrypt this
        await db.commit()
        return {
            "secret": secret,
            "qr_uri": get_totp_uri(secret, user.email),
        }

    async def enable_2fa(self, db: AsyncSession, user_id: UUID, totp_code: str) -> dict:
        user = await db.get(User, user_id)
        if not user.two_fa_secret:
            raise HTTPException(status_code=400, detail="2FA not set up. Call /setup-2fa first.")
        if not verify_totp(user.two_fa_secret, totp_code):
            raise HTTPException(status_code=400, detail="Invalid TOTP code")
        user.two_fa_enabled = True
        await db.commit()
        return {"message": "2FA enabled successfully"}

    async def disable_2fa(self, db: AsyncSession, user_id: UUID, totp_code: str) -> dict:
        user = await db.get(User, user_id)
        if not user.two_fa_enabled:
            raise HTTPException(status_code=400, detail="2FA not enabled")
        if not verify_totp(user.two_fa_secret, totp_code):
            raise HTTPException(status_code=400, detail="Invalid TOTP code")
        user.two_fa_enabled = False
        user.two_fa_secret = None
        await db.commit()
        return {"message": "2FA disabled"}

    # ─────────────────────────────────────────
    # HELPERS
    # ─────────────────────────────────────────

    async def _get_user_by_email(self, db: AsyncSession, email: str) -> Optional[User]:
        result = await db.execute(select(User).where(User.email == email))
        return result.scalar_one_or_none()

    async def _get_valid_otp(self, db: AsyncSession, user_id: UUID, purpose: OTPPurpose) -> Optional[OTPCode]:
        result = await db.execute(
            select(OTPCode).where(
                and_(
                    OTPCode.user_id == user_id,
                    OTPCode.purpose == purpose,
                    OTPCode.used == False,
                    OTPCode.expires_at > datetime.now(timezone.utc),
                    OTPCode.attempts < 5,
                )
            ).order_by(OTPCode.created_at.desc())
        )
        return result.scalars().first()

    async def _increment_otp_attempts(self, db: AsyncSession, otp_record: Optional[OTPCode]):
        if otp_record:
            otp_record.attempts += 1
            await db.commit()

    async def _handle_failed_login(self, db: AsyncSession, user: User):
        user.failed_login_attempts += 1
        if user.failed_login_attempts >= 5:
            user.locked_until = datetime.now(timezone.utc) + timedelta(minutes=30)
        await db.commit()


auth_service = AuthService()
