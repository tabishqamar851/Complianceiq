from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    APP_NAME: str = "ComplianceIQ"
    APP_ENV: str = "development"
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    DATABASE_URL: str
    SYNC_DATABASE_URL: str

    REDIS_URL: str = "redis://localhost:6379/0"

    RAZORPAY_KEY_ID: Optional[str] = None
    RAZORPAY_KEY_SECRET: Optional[str] = None
    RAZORPAY_WEBHOOK_SECRET: Optional[str] = None

    RESEND_API_KEY: Optional[str] = None
    FROM_EMAIL: str = "noreply@complianceiq.in"
    FROM_NAME: str = "ComplianceIQ"

    OTP_EXPIRY_MINUTES: int = 10

    R2_ACCOUNT_ID: Optional[str] = None
    R2_ACCESS_KEY: Optional[str] = None
    R2_SECRET_KEY: Optional[str] = None
    R2_BUCKET: str = "complianceiq-docs"
    R2_PUBLIC_URL: Optional[str] = None

    FRONTEND_URL: str = "http://localhost:3000"

    PLAN_BUSINESS_MONTHLY: Optional[str] = None
    PLAN_BUSINESS_ANNUAL: Optional[str] = None
    PLAN_CA_MONTHLY: Optional[str] = None
    PLAN_CA_ANNUAL: Optional[str] = None

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
