"""
ComplianceIQ - Complete Database Models
Phase 1: Auth + Multi-tenancy + Subscriptions
"""
import uuid
from datetime import datetime
from enum import Enum as PyEnum

from sqlalchemy import (
    Column, String, Boolean, DateTime, ForeignKey,
    Text, Integer, Numeric, Enum, JSON, Index, UniqueConstraint
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship, DeclarativeBase
from sqlalchemy.sql import func


class Base(DeclarativeBase):
    pass


# ─────────────────────────────────────────
# ENUMS
# ─────────────────────────────────────────

class TenantType(str, PyEnum):
    BUSINESS = "business"       # RBI-regulated company (forex dealer etc.)
    CA_FIRM = "ca_firm"         # Chartered Accountant firm
    INDIVIDUAL_CA = "individual_ca"

class UserRole(str, PyEnum):
    SUPER_ADMIN = "super_admin"  # Platform admin
    TENANT_ADMIN = "tenant_admin"
    CA = "ca"
    STAFF = "staff"
    VIEWER = "viewer"
    CLIENT = "client"           # End customer of a CA firm

class SubscriptionPlan(str, PyEnum):
    FREE = "free"
    BUSINESS_MONTHLY = "business_monthly"
    BUSINESS_ANNUAL = "business_annual"
    CA_MONTHLY = "ca_monthly"
    CA_ANNUAL = "ca_annual"
    PER_TASK = "per_task"

class SubscriptionStatus(str, PyEnum):
    ACTIVE = "active"
    TRIAL = "trial"
    PAST_DUE = "past_due"
    CANCELLED = "cancelled"
    EXPIRED = "expired"

class OTPPurpose(str, PyEnum):
    LOGIN = "login"
    EMAIL_VERIFY = "email_verify"
    PASSWORD_RESET = "password_reset"
    TWO_FA_SETUP = "two_fa_setup"

class AuditAction(str, PyEnum):
    LOGIN = "login"
    LOGOUT = "logout"
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    EXPORT = "export"
    PAYMENT = "payment"
    SUBSCRIPTION = "subscription"


# ─────────────────────────────────────────
# TENANT (Organisation)
# ─────────────────────────────────────────

class Tenant(Base):
    __tablename__ = "tenants"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    slug = Column(String(100), unique=True, nullable=False)  # URL identifier
    tenant_type = Column(Enum(TenantType), nullable=False)

    # RBI / regulatory identifiers
    rbi_license_no = Column(String(100))
    gstin = Column(String(15))
    pan = Column(String(10))
    fema_ad_code = Column(String(50))   # Authorised Dealer code

    # Contact
    email = Column(String(255), nullable=False)
    phone = Column(String(20))
    address = Column(Text)
    city = Column(String(100))
    state = Column(String(100))
    pincode = Column(String(10))

    # Status
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    verified_at = Column(DateTime(timezone=True))

    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    users = relationship("User", back_populates="tenant", cascade="all, delete-orphan")
    subscription = relationship("Subscription", back_populates="tenant", uselist=False)
    entities = relationship("ManagedEntity", back_populates="tenant")
    audit_logs = relationship("AuditLog", back_populates="tenant")

    __table_args__ = (
        Index("ix_tenants_slug", "slug"),
        Index("ix_tenants_gstin", "gstin"),
    )


# ─────────────────────────────────────────
# USER
# ─────────────────────────────────────────

class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False)

    email = Column(String(255), nullable=False)
    phone = Column(String(20))
    full_name = Column(String(255), nullable=False)
    hashed_password = Column(String(255), nullable=False)

    role = Column(Enum(UserRole), nullable=False, default=UserRole.STAFF)

    # Professional details (for CAs)
    membership_no = Column(String(50))      # ICAI membership number
    firm_name = Column(String(255))

    # Status
    is_active = Column(Boolean, default=True)
    is_email_verified = Column(Boolean, default=False)
    is_phone_verified = Column(Boolean, default=False)

    # 2FA
    two_fa_enabled = Column(Boolean, default=False)
    two_fa_secret = Column(String(100))     # TOTP secret (encrypted)

    # Login tracking
    last_login_at = Column(DateTime(timezone=True))
    last_login_ip = Column(String(45))
    failed_login_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime(timezone=True))

    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    tenant = relationship("Tenant", back_populates="users")
    otp_codes = relationship("OTPCode", back_populates="user", cascade="all, delete-orphan")
    refresh_tokens = relationship("RefreshToken", back_populates="user", cascade="all, delete-orphan")
    audit_logs = relationship("AuditLog", back_populates="user")

    __table_args__ = (
        UniqueConstraint("tenant_id", "email", name="uq_tenant_user_email"),
        Index("ix_users_email", "email"),
        Index("ix_users_tenant_id", "tenant_id"),
    )


# ─────────────────────────────────────────
# AUTH TOKENS
# ─────────────────────────────────────────

class RefreshToken(Base):
    __tablename__ = "refresh_tokens"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    token_hash = Column(String(255), nullable=False, unique=True)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    revoked = Column(Boolean, default=False)
    device_info = Column(String(500))
    ip_address = Column(String(45))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="refresh_tokens")

    __table_args__ = (Index("ix_refresh_tokens_token_hash", "token_hash"),)


class OTPCode(Base):
    __tablename__ = "otp_codes"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    code_hash = Column(String(255), nullable=False)
    purpose = Column(Enum(OTPPurpose), nullable=False)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    used = Column(Boolean, default=False)
    attempts = Column(Integer, default=0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="otp_codes")

    __table_args__ = (Index("ix_otp_user_purpose", "user_id", "purpose"),)


# ─────────────────────────────────────────
# SUBSCRIPTIONS
# ─────────────────────────────────────────

class Subscription(Base):
    __tablename__ = "subscriptions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, unique=True)

    plan = Column(Enum(SubscriptionPlan), nullable=False, default=SubscriptionPlan.FREE)
    status = Column(Enum(SubscriptionStatus), nullable=False, default=SubscriptionStatus.TRIAL)

    # Razorpay
    razorpay_subscription_id = Column(String(100))
    razorpay_customer_id = Column(String(100))
    razorpay_plan_id = Column(String(100))

    # Dates
    trial_ends_at = Column(DateTime(timezone=True))
    current_period_start = Column(DateTime(timezone=True))
    current_period_end = Column(DateTime(timezone=True))
    cancelled_at = Column(DateTime(timezone=True))

    # Limits per plan
    max_users = Column(Integer, default=3)
    max_entities = Column(Integer, default=5)     # companies managed
    max_tasks_per_month = Column(Integer, default=50)

    # Per-task balance (for pay-as-you-go)
    task_credits = Column(Integer, default=0)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    tenant = relationship("Tenant", back_populates="subscription")
    payments = relationship("Payment", back_populates="subscription")


class Payment(Base):
    __tablename__ = "payments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    subscription_id = Column(UUID(as_uuid=True), ForeignKey("subscriptions.id"), nullable=False)
    tenant_id = Column(UUID(as_uuid=True), ForeignKey("tenants.id"), nullable=False)

    amount = Column(Numeric(10, 2), nullable=False)
    currency = Column(String(3), default="INR")
    gst_amount = Column(Numeric(10, 2), default=0)
    total_amount = Column(Numeric(10, 2), nullable=False)

    razorpay_payment_id = Column(String(100))
    razorpay_order_id = Column(String(100))
    razorpay_invoice_id = Column(String(100))

    status = Column(String(50), default="pending")  # pending, captured, failed, refunded
    description = Column(String(500))

    # GST invoice details
    invoice_number = Column(String(50))
    invoice_url = Column(String(500))

    paid_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    subscription = relationship("Subscription", back_populates="payments")


# ─────────────────────────────────────────
# MANAGED ENTITIES (companies managed by CA)
# ─────────────────────────────────────────

class ManagedEntity(Base):
    """A company/client being tracked for compliance by a tenant"""
    __tablename__ = "managed_entities"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False)

    name = Column(String(255), nullable=False)
    entity_type = Column(String(100))   # Pvt Ltd, LLP, Proprietorship, etc.

    # Regulatory identifiers
    gstin = Column(String(15))
    pan = Column(String(10))
    cin = Column(String(21))             # Company identification number
    rbi_license_no = Column(String(100))
    fema_ad_code = Column(String(50))
    lei_code = Column(String(20))        # Legal Entity Identifier

    # Contact
    email = Column(String(255))
    phone = Column(String(20))
    address = Column(Text)

    # Compliance profile
    is_fema_applicable = Column(Boolean, default=False)
    is_rbi_regulated = Column(Boolean, default=False)
    is_aml_applicable = Column(Boolean, default=True)
    fx_dealer_category = Column(String(50))  # AD-I, AD-II, FFMC

    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    tenant = relationship("Tenant", back_populates="entities")

    __table_args__ = (Index("ix_entities_tenant_id", "tenant_id"),)


# ─────────────────────────────────────────
# AUDIT LOG (immutable, every action)
# ─────────────────────────────────────────

class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(UUID(as_uuid=True), ForeignKey("tenants.id"), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)

    action = Column(Enum(AuditAction), nullable=False)
    resource_type = Column(String(100))
    resource_id = Column(String(100))
    description = Column(Text)

    # Snapshot of changes
    old_values = Column(JSON)
    new_values = Column(JSON)

    # Request context
    ip_address = Column(String(45))
    user_agent = Column(String(500))
    request_id = Column(String(100))

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    tenant = relationship("Tenant", back_populates="audit_logs")
    user = relationship("User", back_populates="audit_logs")

    __table_args__ = (
        Index("ix_audit_tenant_created", "tenant_id", "created_at"),
        Index("ix_audit_user_id", "user_id"),
    )
