"""
Users, Tenant, and Managed Entities endpoints
"""
from typing import List
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.core.dependencies import get_current_user, get_current_tenant, require_roles
from app.models.models import User, Tenant, ManagedEntity, UserRole, AuditLog, AuditAction
from app.schemas.schemas import (
    UserCreate, UserResponse, TenantResponse,
    EntityCreate, EntityResponse
)
from app.core.security import hash_password, validate_password_strength

router = APIRouter(tags=["Users & Entities"])


# ─────────────────────────────────────────
# TENANT
# ─────────────────────────────────────────

@router.get("/tenant", response_model=TenantResponse)
async def get_tenant(tenant: Tenant = Depends(get_current_tenant)):
    return tenant


@router.patch("/tenant")
async def update_tenant(
    updates: dict,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.TENANT_ADMIN, UserRole.SUPER_ADMIN)),
    tenant: Tenant = Depends(get_current_tenant),
):
    allowed = {"name", "phone", "address", "city", "state", "pincode", "gstin", "pan"}
    for key, val in updates.items():
        if key in allowed:
            setattr(tenant, key, val)
    await db.commit()
    return {"message": "Tenant updated"}


# ─────────────────────────────────────────
# USERS
# ─────────────────────────────────────────

@router.get("/users", response_model=List[UserResponse])
async def list_users(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.TENANT_ADMIN, UserRole.SUPER_ADMIN)),
):
    result = await db.execute(
        select(User).where(User.tenant_id == current_user.tenant_id)
    )
    return result.scalars().all()


@router.post("/users", response_model=UserResponse, status_code=201)
async def create_user(
    data: UserCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.TENANT_ADMIN, UserRole.SUPER_ADMIN)),
):
    # Check subscription limit
    from sqlalchemy import func
    from app.models.models import Subscription
    sub_result = await db.execute(
        select(Subscription).where(Subscription.tenant_id == current_user.tenant_id)
    )
    sub = sub_result.scalar_one_or_none()
    count_result = await db.execute(
        select(func.count(User.id)).where(User.tenant_id == current_user.tenant_id)
    )
    count = count_result.scalar()
    if sub and count >= sub.max_users:
        raise HTTPException(
            status_code=402,
            detail=f"User limit reached ({sub.max_users}). Please upgrade your plan."
        )

    # Unique email within tenant
    existing = await db.execute(
        select(User).where(User.email == data.email, User.tenant_id == current_user.tenant_id)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Email already exists in this organisation")

    valid, msg = validate_password_strength(data.password)
    if not valid:
        raise HTTPException(status_code=422, detail=msg)

    user = User(
        tenant_id=current_user.tenant_id,
        email=data.email,
        full_name=data.full_name,
        phone=data.phone,
        hashed_password=hash_password(data.password),
        role=data.role,
        membership_no=data.membership_no,
        is_email_verified=True,  # Admin-created users skip email verify
    )
    db.add(user)
    db.add(AuditLog(
        tenant_id=current_user.tenant_id,
        user_id=current_user.id,
        action=AuditAction.CREATE,
        resource_type="user",
        description=f"Created user {data.email}",
    ))
    await db.commit()
    await db.refresh(user)
    return user


@router.patch("/users/{user_id}/deactivate")
async def deactivate_user(
    user_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.TENANT_ADMIN)),
):
    user = await db.get(User, user_id)
    if not user or user.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="User not found")
    if user.id == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot deactivate yourself")
    user.is_active = False
    await db.commit()
    return {"message": "User deactivated"}


# ─────────────────────────────────────────
# MANAGED ENTITIES
# ─────────────────────────────────────────

@router.get("/entities", response_model=List[EntityResponse])
async def list_entities(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(ManagedEntity).where(
            ManagedEntity.tenant_id == current_user.tenant_id,
            ManagedEntity.is_active == True,
        )
    )
    return result.scalars().all()


@router.post("/entities", response_model=EntityResponse, status_code=201)
async def create_entity(
    data: EntityCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(
        UserRole.TENANT_ADMIN, UserRole.CA, UserRole.SUPER_ADMIN
    )),
):
    from sqlalchemy import func
    from app.models.models import Subscription
    sub_result = await db.execute(
        select(Subscription).where(Subscription.tenant_id == current_user.tenant_id)
    )
    sub = sub_result.scalar_one_or_none()
    count_result = await db.execute(
        select(func.count(ManagedEntity.id)).where(
            ManagedEntity.tenant_id == current_user.tenant_id
        )
    )
    count = count_result.scalar()
    if sub and count >= sub.max_entities:
        raise HTTPException(
            status_code=402,
            detail=f"Entity limit reached ({sub.max_entities}). Please upgrade."
        )

    entity = ManagedEntity(
        tenant_id=current_user.tenant_id,
        **data.model_dump()
    )
    db.add(entity)
    await db.commit()
    await db.refresh(entity)
    return entity


@router.get("/entities/{entity_id}", response_model=EntityResponse)
async def get_entity(
    entity_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    entity = await db.get(ManagedEntity, entity_id)
    if not entity or entity.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="Entity not found")
    return entity


@router.delete("/entities/{entity_id}")
async def delete_entity(
    entity_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.TENANT_ADMIN, UserRole.CA)),
):
    entity = await db.get(ManagedEntity, entity_id)
    if not entity or entity.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="Entity not found")
    entity.is_active = False  # Soft delete
    await db.commit()
    return {"message": "Entity removed"}
