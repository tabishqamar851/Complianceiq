"""
Subscription & Billing endpoints
- View current plan
- Create Razorpay order
- Verify payment + activate subscription
- Webhook handler
"""
import hashlib
import hmac
import json
from datetime import datetime, timedelta, timezone

import razorpay
from fastapi import APIRouter, Depends, HTTPException, Request, Header
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.dependencies import get_current_user, get_current_tenant
from app.db.database import get_db
from app.models.models import (
    User, Tenant, Subscription, Payment,
    SubscriptionPlan, SubscriptionStatus, AuditLog, AuditAction
)
from app.schemas.schemas import SubscriptionResponse, CreateOrderRequest, CreateOrderResponse

router = APIRouter(prefix="/billing", tags=["Billing & Subscriptions"])

# Plan config: amount in paise, limits
PLAN_CONFIG = {
    SubscriptionPlan.BUSINESS_MONTHLY: {
        "amount": 299900,       # ₹2,999/month
        "max_users": 10,
        "max_entities": 25,
        "max_tasks": 500,
        "label": "Business Monthly",
    },
    SubscriptionPlan.BUSINESS_ANNUAL: {
        "amount": 2399900,      # ₹23,999/year (~₹2,000/month)
        "max_users": 10,
        "max_entities": 25,
        "max_tasks": 9999,
        "label": "Business Annual",
    },
    SubscriptionPlan.CA_MONTHLY: {
        "amount": 499900,       # ₹4,999/month
        "max_users": 25,
        "max_entities": 100,
        "max_tasks": 9999,
        "label": "CA Professional Monthly",
    },
    SubscriptionPlan.CA_ANNUAL: {
        "amount": 3999900,      # ₹39,999/year
        "max_users": 25,
        "max_entities": 100,
        "max_tasks": 9999,
        "label": "CA Professional Annual",
    },
}

PER_TASK_PRICE = 4900  # ₹49 per task credit


@router.get("/subscription", response_model=SubscriptionResponse)
async def get_subscription(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Subscription).where(Subscription.tenant_id == current_user.tenant_id)
    )
    sub = result.scalar_one_or_none()
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    return sub


@router.get("/plans")
async def list_plans():
    """List all available subscription plans."""
    return {
        "plans": [
            {
                "id": plan.value,
                "label": config["label"],
                "amount_paise": config["amount"],
                "amount_inr": config["amount"] / 100,
                "max_users": config["max_users"],
                "max_entities": config["max_entities"],
            }
            for plan, config in PLAN_CONFIG.items()
        ],
        "per_task": {
            "price_inr": PER_TASK_PRICE / 100,
            "description": "Pay per compliance task — no subscription needed",
        }
    }


@router.post("/create-order", response_model=CreateOrderResponse)
async def create_order(
    data: CreateOrderRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
    tenant: Tenant = Depends(get_current_tenant),
):
    """Create a Razorpay order for subscription purchase."""
    if not settings.RAZORPAY_KEY_ID:
        raise HTTPException(status_code=503, detail="Payment gateway not configured")

    plan_config = PLAN_CONFIG.get(data.plan)
    if not plan_config:
        raise HTTPException(status_code=400, detail="Invalid plan selected")

    client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))

    gst_amount = int(plan_config["amount"] * 0.18)
    total_amount = plan_config["amount"] + gst_amount

    order = client.order.create({
        "amount": total_amount,
        "currency": "INR",
        "notes": {
            "tenant_id": str(tenant.id),
            "plan": data.plan.value,
            "tenant_name": tenant.name,
        }
    })

    return CreateOrderResponse(
        order_id=order["id"],
        amount=total_amount,
        currency="INR",
        razorpay_key=settings.RAZORPAY_KEY_ID,
        plan=data.plan.value,
    )


@router.post("/verify-payment")
async def verify_payment(
    payment_data: dict,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Verify Razorpay payment signature and activate subscription.
    Call this after successful payment on frontend.
    """
    required = ["razorpay_order_id", "razorpay_payment_id", "razorpay_signature", "plan"]
    for field in required:
        if field not in payment_data:
            raise HTTPException(status_code=400, detail=f"Missing field: {field}")

    # Verify signature
    key = settings.RAZORPAY_KEY_SECRET.encode()
    msg = f"{payment_data['razorpay_order_id']}|{payment_data['razorpay_payment_id']}".encode()
    expected = hmac.new(key, msg, hashlib.sha256).hexdigest()

    if not hmac.compare_digest(expected, payment_data["razorpay_signature"]):
        raise HTTPException(status_code=400, detail="Payment verification failed")

    # Activate subscription
    plan = SubscriptionPlan(payment_data["plan"])
    plan_config = PLAN_CONFIG[plan]

    is_annual = "annual" in plan.value
    period_end = datetime.now(timezone.utc) + timedelta(days=365 if is_annual else 30)

    result = await db.execute(
        select(Subscription).where(Subscription.tenant_id == current_user.tenant_id)
    )
    sub = result.scalar_one_or_none()

    if sub:
        sub.plan = plan
        sub.status = SubscriptionStatus.ACTIVE
        sub.current_period_start = datetime.now(timezone.utc)
        sub.current_period_end = period_end
        sub.max_users = plan_config["max_users"]
        sub.max_entities = plan_config["max_entities"]
        sub.max_tasks_per_month = plan_config["max_tasks"]
        sub.razorpay_payment_id = payment_data["razorpay_payment_id"]
    else:
        sub = Subscription(
            tenant_id=current_user.tenant_id,
            plan=plan,
            status=SubscriptionStatus.ACTIVE,
            current_period_start=datetime.now(timezone.utc),
            current_period_end=period_end,
            max_users=plan_config["max_users"],
            max_entities=plan_config["max_entities"],
            max_tasks_per_month=plan_config["max_tasks"],
        )
        db.add(sub)

    # Record payment
    await db.flush()
    amount_inr = plan_config["amount"] / 100
    gst = amount_inr * 0.18
    payment = Payment(
        subscription_id=sub.id,
        tenant_id=current_user.tenant_id,
        amount=amount_inr,
        gst_amount=gst,
        total_amount=amount_inr + gst,
        razorpay_payment_id=payment_data["razorpay_payment_id"],
        razorpay_order_id=payment_data["razorpay_order_id"],
        status="captured",
        paid_at=datetime.now(timezone.utc),
    )
    db.add(payment)

    db.add(AuditLog(
        tenant_id=current_user.tenant_id,
        user_id=current_user.id,
        action=AuditAction.PAYMENT,
        resource_type="subscription",
        description=f"Subscription activated: {plan.value}",
    ))

    await db.commit()
    return {"message": "Subscription activated successfully", "plan": plan.value}


@router.post("/buy-task-credits")
async def buy_task_credits(
    data: dict,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Buy per-task credits (pay-as-you-go)."""
    quantity = data.get("quantity", 1)
    if quantity < 1 or quantity > 100:
        raise HTTPException(status_code=400, detail="Quantity must be between 1 and 100")

    if not settings.RAZORPAY_KEY_ID:
        raise HTTPException(status_code=503, detail="Payment gateway not configured")

    client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
    amount = PER_TASK_PRICE * quantity
    gst = int(amount * 0.18)
    total = amount + gst

    order = client.order.create({
        "amount": total,
        "currency": "INR",
        "notes": {
            "tenant_id": str(current_user.tenant_id),
            "type": "per_task",
            "quantity": quantity,
        }
    })
    return {
        "order_id": order["id"],
        "amount": total,
        "quantity": quantity,
        "price_per_task_inr": PER_TASK_PRICE / 100,
        "razorpay_key": settings.RAZORPAY_KEY_ID,
    }
