"""
Auth endpoints - ComplianceIQ
POST /auth/register
POST /auth/verify-email
POST /auth/login
POST /auth/refresh
POST /auth/logout
POST /auth/forgot-password
POST /auth/reset-password
POST /auth/change-password
GET  /auth/setup-2fa
POST /auth/enable-2fa
POST /auth/disable-2fa
GET  /auth/me
"""
from fastapi import APIRouter, Depends, Request, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.core.dependencies import get_current_user, get_client_ip
from app.models.models import User
from app.schemas.schemas import (
    RegisterRequest, LoginRequest, OTPVerifyRequest,
    RefreshTokenRequest, PasswordResetRequest, PasswordResetConfirm,
    ChangePasswordRequest, Verify2FARequest, TokenResponse, UserResponse
)
from app.services.auth_service import auth_service

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/register", status_code=201)
async def register(data: RegisterRequest, db: AsyncSession = Depends(get_db)):
    """Register a new tenant + admin user. Sends email verification OTP."""
    return await auth_service.register(db, data)


@router.post("/verify-email")
async def verify_email(data: OTPVerifyRequest, db: AsyncSession = Depends(get_db)):
    """Verify email with OTP received after registration."""
    return await auth_service.verify_email(db, data.email, data.otp)


@router.post("/login")
async def login(
    data: LoginRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """
    Login with email + password.
    If 2FA is enabled, also provide totp_code.
    Returns access_token + refresh_token.
    """
    ip = get_client_ip(request)
    user_agent = request.headers.get("User-Agent", "")
    return await auth_service.login(db, data, ip, user_agent)


@router.post("/refresh")
async def refresh_tokens(data: RefreshTokenRequest, db: AsyncSession = Depends(get_db)):
    """Get new access + refresh tokens using a valid refresh token."""
    return await auth_service.refresh_tokens(db, data.refresh_token)


@router.post("/logout")
async def logout(
    data: RefreshTokenRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Revoke refresh token (logout from this device)."""
    from sqlalchemy import select, and_
    from app.models.models import RefreshToken, AuditLog, AuditAction
    from app.core.security import hash_token

    token_hash = hash_token(data.refresh_token)
    result = await db.execute(
        select(RefreshToken).where(
            and_(RefreshToken.token_hash == token_hash, RefreshToken.user_id == current_user.id)
        )
    )
    rt = result.scalar_one_or_none()
    if rt:
        rt.revoked = True

    db.add(AuditLog(
        tenant_id=current_user.tenant_id,
        user_id=current_user.id,
        action=AuditAction.LOGOUT,
        resource_type="user",
        resource_id=str(current_user.id),
        description="User logged out",
    ))
    await db.commit()
    return {"message": "Logged out successfully"}


@router.post("/forgot-password")
async def forgot_password(data: PasswordResetRequest, db: AsyncSession = Depends(get_db)):
    """Request password reset OTP (always returns success to prevent email enumeration)."""
    return await auth_service.request_password_reset(db, data.email)


@router.post("/reset-password")
async def reset_password(data: PasswordResetConfirm, db: AsyncSession = Depends(get_db)):
    """Reset password using OTP from email."""
    return await auth_service.confirm_password_reset(
        db, data.email, data.otp, data.new_password
    )


@router.post("/change-password")
async def change_password(
    data: ChangePasswordRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Change password (must know current password)."""
    from app.core.security import verify_password, hash_password, validate_password_strength
    if not verify_password(data.current_password, current_user.hashed_password):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    valid, msg = validate_password_strength(data.new_password)
    if not valid:
        raise HTTPException(status_code=422, detail=msg)
    current_user.hashed_password = hash_password(data.new_password)
    await db.commit()
    return {"message": "Password changed successfully"}


@router.get("/setup-2fa")
async def setup_2fa(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get TOTP secret + QR code URI for Google Authenticator setup."""
    return await auth_service.setup_2fa(db, current_user.id)


@router.post("/enable-2fa")
async def enable_2fa(
    data: Verify2FARequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Verify TOTP code and enable 2FA on account."""
    return await auth_service.enable_2fa(db, current_user.id, data.totp_code)


@router.post("/disable-2fa")
async def disable_2fa(
    data: Verify2FARequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Disable 2FA (requires current valid TOTP code as confirmation)."""
    return await auth_service.disable_2fa(db, current_user.id, data.totp_code)


@router.get("/me", response_model=UserResponse)
async def get_me(current_user: User = Depends(get_current_user)):
    """Get current logged-in user's profile."""
    return current_user
