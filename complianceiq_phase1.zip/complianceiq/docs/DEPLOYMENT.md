# ─────────────────────────────────────────
# ComplianceIQ - Deployment Guide
# ─────────────────────────────────────────

## FREE DEPLOYMENT ON RAILWAY.APP

### Step 1: Push to GitHub
```bash
git init
git add .
git commit -m "ComplianceIQ Phase 1 - Auth + Subscriptions"
git remote add origin https://github.com/yourusername/complianceiq.git
git push -u origin main
```

### Step 2: Deploy on Railway (Free)
1. Go to https://railway.app
2. Click "New Project" → "Deploy from GitHub Repo"
3. Select your repo
4. Railway auto-detects Python → Adds build/start commands

### Step 3: Add Services on Railway
- Add PostgreSQL: Click "+ New" → "Database" → "PostgreSQL"
- Add Redis: Click "+ New" → "Database" → "Redis"
- Railway automatically sets DATABASE_URL and REDIS_URL

### Step 4: Set Environment Variables in Railway
Go to your service → Variables → Add all from .env.example

### Step 5: Run Migrations
In Railway shell:
```bash
alembic upgrade head
```

## DOCKER SETUP (for VPS)
See Dockerfile below.
