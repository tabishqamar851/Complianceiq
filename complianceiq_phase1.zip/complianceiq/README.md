# ComplianceIQ — Phase 1

India's compliance platform for RBI-regulated entities and CA firms.

## What's Built in Phase 1

### Backend (FastAPI + PostgreSQL)
- ✅ Multi-tenant architecture (Business / CA Firm / Individual CA)
- ✅ Full auth system: Register, Email OTP verification, Login, Logout
- ✅ JWT access tokens + rotating refresh tokens
- ✅ 2FA (TOTP / Google Authenticator)
- ✅ Account lockout (5 failed attempts → 30 min lock)
- ✅ Role-based access control (Super Admin / Tenant Admin / CA / Staff / Viewer)
- ✅ Password strength enforcement (10+ chars, uppercase, number, symbol)
- ✅ Subscription system (Business / CA / Per-Task) with Razorpay
- ✅ Managed Entities (companies tracked for compliance)
- ✅ Immutable audit log (every action recorded)
- ✅ Security headers, CORS, rate-limiting ready

### Frontend (HTML/CSS/JS)
- ✅ Landing page with hero, features, pricing
- ✅ Registration flow with OTP verification
- ✅ Login with 2FA support
- ✅ Full dashboard with sidebar navigation
- ✅ Entities management
- ✅ Subscription page (Razorpay-ready)
- ✅ Audit log view
- ✅ Compliance module placeholders (Phase 3–6)

---

## Quick Start (Local)

### Option A: Docker (Recommended)
```bash
# Clone and start everything
docker-compose up --build

# API: http://localhost:8000
# Frontend: http://localhost:3000
# API Docs: http://localhost:8000/docs
```

### Option B: Manual
```bash
# 1. Setup PostgreSQL + Redis (local)

# 2. Backend
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your DB credentials

# 3. Run
uvicorn app.main:app --reload

# 4. Frontend
# Open frontend/index.html in browser
# Or serve with: python -m http.server 3000 (in frontend/)
```

---

## Deploy to Railway (Free)

1. Push this repo to GitHub
2. Go to railway.app → New Project → Deploy from GitHub
3. Select the `backend/` folder as root
4. Add PostgreSQL + Redis services
5. Set env variables (from .env.example)
6. Deploy!

For frontend: Deploy `frontend/` to Vercel or Netlify (free)

---

## API Documentation

When running in development, full interactive docs at:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

### Key Endpoints

```
POST /api/v1/auth/register          Register tenant + admin user
POST /api/v1/auth/verify-email      Verify email with OTP
POST /api/v1/auth/login             Login (returns JWT tokens)
POST /api/v1/auth/refresh           Refresh access token
POST /api/v1/auth/logout            Revoke refresh token
POST /api/v1/auth/forgot-password   Request password reset OTP
POST /api/v1/auth/reset-password    Reset password with OTP
GET  /api/v1/auth/setup-2fa         Get TOTP secret + QR code
POST /api/v1/auth/enable-2fa        Enable 2FA
GET  /api/v1/auth/me                Get current user

GET  /api/v1/tenant                 Get organisation details
GET  /api/v1/users                  List users (admin only)
POST /api/v1/users                  Create user (admin only)
GET  /api/v1/entities               List managed entities
POST /api/v1/entities               Add managed entity

GET  /api/v1/billing/plans          List subscription plans
GET  /api/v1/billing/subscription   Current subscription
POST /api/v1/billing/create-order   Create Razorpay order
POST /api/v1/billing/verify-payment Verify payment + activate
```

---

## Roadmap

| Phase | Module | Status |
|-------|--------|--------|
| 1 | Auth + Multi-tenancy + Subscriptions | ✅ Done |
| 2 | Razorpay live integration + billing UI | Next |
| 3 | FEMA compliance logic | Planned |
| 4 | RBI regulations module | Planned |
| 5 | GST/Tax module | Planned |
| 6 | AML/KYC module | Planned |
| 7 | Document generation (PDF) | Planned |
| 8 | Alerts & notifications | Planned |
| 9 | Analytics dashboard | Planned |
| 10 | Security hardening + production deploy | Planned |

---

## ⚠️ Legal Disclaimer

This software provides compliance assistance tools only. All outputs,
checklists, calculations, and recommendations must be independently
reviewed and verified by a qualified Chartered Accountant, Company
Secretary, or legal professional before acting on them.

ComplianceIQ and its developers are not responsible for any decisions
made based on outputs from this platform.

Compliance rules change frequently. Ensure the platform is updated
whenever RBI/FEMA/GST regulations are updated.
